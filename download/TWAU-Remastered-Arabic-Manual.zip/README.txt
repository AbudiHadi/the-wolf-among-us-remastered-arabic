The Wolf Among Us Remastered - Arabic translation - version 1.0.0
Translation: Abdullah Hadi
Engine work: Lexara (formerly RTL Forge)

=============================================
     Manual install (one minute)
=============================================

1) Close the game completely.
2) In Steam: right-click the game -> Manage -> Browse local files
3) Copy the "Archives" folder from this zip into the game folder
   (next to TheWolfAmongUsRemastered.exe) and merge.
   Only two files are added inside Archives:
     Fables_pc_Arabic_ar_all.ttarch2
     _resdesc_50_Arabic.lua
   No original file is replaced, so no backup is needed.
4) Start the game. Arabic appears in place of English;
   no setting has to be changed.

=============================================
     Notes
=============================================

- Voices stay English; only the text is translated.
- Older version installed? Copy the two new files over the old ones.
- Game updates and Steam's file verification leave the two files in
  place; if an update changes the game's text, wait for a new release.
- The Arabic text is bound to the translation's fonts: copying or
  editing it outside this package gives unreadable text.

=============================================
     Back to the original
=============================================

Delete the two files from the Archives folder:
  Fables_pc_Arabic_ar_all.ttarch2
  _resdesc_50_Arabic.lua
The game is English again immediately.
